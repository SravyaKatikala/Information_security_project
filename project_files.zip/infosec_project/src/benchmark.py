import time
import statistics
import platform
import os
import csv

from vault import derive_key_pbkdf2, derive_key_argon2id


TRIALS = 10
MEMORY_VALUES = [16, 32, 64, 128]


def benchmark_kdf(kdf_function, pin, salt, trials=TRIALS):

    times = []

    # Warm-up
    kdf_function(pin, salt)

    for _ in range(trials):

        start = time.perf_counter()

        kdf_function(pin, salt)

        elapsed = time.perf_counter() - start

        times.append(elapsed)

    return times


def summarize(times):

    mean_time = statistics.mean(times)

    return {
        "mean": mean_time,
        "std": statistics.stdev(times),
        "min": min(times),
        "max": max(times),
        "guesses_per_second": 1 / mean_time
    }


def benchmark_argon2_memory(pin, salt, memory_mib):

    memory_kib = memory_mib * 1024

    def argon2_function(pin, salt):

        return derive_key_argon2id(
            pin,
            salt,
            memory_kib
        )

    times = benchmark_kdf(
        argon2_function,
        pin,
        salt
    )

    return times


def save_raw_results(raw_results):

    os.makedirs("results", exist_ok=True)

    filename = "results/kdf_benchmark_raw.csv"

    with open(filename, "w", newline="") as file:

        writer = csv.writer(file)

        writer.writerow([
            "KDF",
            "Memory_MiB",
            "Trial",
            "Time_seconds",
            "Guesses_per_second"
        ])

        for result in raw_results:

            writer.writerow([
                result["kdf"],
                result["memory"],
                result["trial"],
                result["time"],
                1 / result["time"]
            ])

    print(f"\nRaw results saved to: {filename}")


def save_summary(summary_results):

    filename = "results/kdf_benchmark_summary.csv"

    with open(filename, "w", newline="") as file:

        writer = csv.writer(file)

        writer.writerow([
            "KDF",
            "Memory_MiB",
            "Mean_seconds",
            "Std_seconds",
            "Min_seconds",
            "Max_seconds",
            "Guesses_per_second",
            "Slowdown_vs_PBKDF2"
        ])

        for result in summary_results:

            writer.writerow([
                result["kdf"],
                result["memory"],
                result["mean"],
                result["std"],
                result["min"],
                result["max"],
                result["guesses_per_second"],
                result["slowdown"]
            ])

    print(f"Summary saved to: {filename}")


def create_graph(summary_results):

    import matplotlib.pyplot as plt

    argon_results = [
        r for r in summary_results
        if r["kdf"] == "Argon2id"
    ]

    memory = [
        r["memory"]
        for r in argon_results
    ]

    guesses = [
        r["guesses_per_second"]
        for r in argon_results
    ]

    plt.figure(figsize=(8, 5))

    plt.plot(
        memory,
        guesses,
        marker="o"
    )

    plt.xlabel("Argon2id Memory Cost (MiB)")
    plt.ylabel("Guesses per Second")

    plt.title(
        "Effect of Argon2id Memory Cost on Guessing Rate"
    )

    plt.xticks(memory)

    plt.grid(True)

    plt.tight_layout()

    filename = "results/argon2id_memory_vs_guesses.png"

    plt.savefig(filename, dpi=300)

    plt.show()

    print(f"Graph saved to: {filename}")


def main():

    pin = "1234"

    # Same salt for all measurements
    salt = os.urandom(16)

    print("=== KDF BENCHMARK ===")
    print()

    print("System:")
    print("OS:", platform.system(), platform.release())
    print("Python:", platform.python_version())
    print("Trials per configuration:", TRIALS)
    print()

    raw_results = []
    summary_results = []

    # ==================================================
    # PBKDF2 BASELINE
    # ==================================================

    print("Benchmarking PBKDF2...")

    pbkdf2_times = benchmark_kdf(
        derive_key_pbkdf2,
        pin,
        salt
    )

    pbkdf2_summary = summarize(pbkdf2_times)

    print(
        f"PBKDF2 mean: "
        f"{pbkdf2_summary['mean']:.6f} seconds"
    )

    print(
        f"PBKDF2 guesses/sec: "
        f"{pbkdf2_summary['guesses_per_second']:.2f}"
    )

    # Raw PBKDF2 results
    for i, elapsed in enumerate(pbkdf2_times, start=1):

        raw_results.append({
            "kdf": "PBKDF2",
            "memory": "N/A",
            "trial": i,
            "time": elapsed
        })

    # ==================================================
    # ARGON2ID
    # ==================================================

    for memory in MEMORY_VALUES:

        print(
            f"\nBenchmarking Argon2id "
            f"with {memory} MiB..."
        )

        times = benchmark_argon2_memory(
            pin,
            salt,
            memory
        )

        result = summarize(times)

        slowdown = (
            result["mean"] /
            pbkdf2_summary["mean"]
        )

        print(
            f"Mean: {result['mean']:.6f} seconds"
        )

        print(
            f"Std: {result['std']:.6f} seconds"
        )

        print(
            f"Guesses/sec: "
            f"{result['guesses_per_second']:.2f}"
        )

        print(
            f"Slowdown: "
            f"{slowdown:.2f}x"
        )

        # Raw results
        for i, elapsed in enumerate(times, start=1):

            raw_results.append({
                "kdf": "Argon2id",
                "memory": memory,
                "trial": i,
                "time": elapsed
            })

        # Summary
        summary_results.append({
            "kdf": "Argon2id",
            "memory": memory,
            "mean": result["mean"],
            "std": result["std"],
            "min": result["min"],
            "max": result["max"],
            "guesses_per_second": result["guesses_per_second"],
            "slowdown": slowdown
        })

    # Add PBKDF2 summary
    summary_results.insert(0, {
        "kdf": "PBKDF2",
        "memory": "N/A",
        "mean": pbkdf2_summary["mean"],
        "std": pbkdf2_summary["std"],
        "min": pbkdf2_summary["min"],
        "max": pbkdf2_summary["max"],
        "guesses_per_second":
            pbkdf2_summary["guesses_per_second"],
        "slowdown": 1.0
    })

    # ==================================================
    # SAVE RESULTS
    # ==================================================

    save_raw_results(raw_results)

    save_summary(summary_results)

    # ==================================================
    # GRAPH
    # ==================================================

    create_graph(summary_results)

    print("\n=== BENCHMARK COMPLETE ===")


if __name__ == "__main__":
    main()