import time

from cryptography.hazmat.primitives.ciphers.aead import AESGCM
from vault import (
    derive_key_pbkdf2,
    derive_key_argon2id
)


def generate_pins(length):

    for number in range(10 ** length):
        yield f"{number:0{length}d}"


def crack_pin(
    ciphertext,
    nonce,
    salt,
    pin_length,
    kdf="pbkdf2"
):

    start_time = time.perf_counter()
    guesses = 0

    for pin in generate_pins(pin_length):

        guesses += 1

        if kdf == "pbkdf2":

            key = derive_key_pbkdf2(
                pin,
                salt
            )

        elif kdf == "argon2id":

            key = derive_key_argon2id(
                pin,
                salt
            )

        else:

            raise ValueError(
                "Unsupported KDF"
            )

        aes = AESGCM(key)

        try:

            aes.decrypt(
                nonce,
                ciphertext,
                None
            )

            elapsed_time = (
                time.perf_counter()
                - start_time
            )

            guesses_per_second = (
                guesses / elapsed_time
            )

            return {
                "pin": pin,
                "guesses": guesses,
                "time": elapsed_time,
                "guesses_per_second":
                    guesses_per_second
            }

        except Exception:

            continue

    return None


def print_results(name, result):

    print(f"\n=== {name} VALIDATION ===")

    if result is None:

        print("PIN not found.")
        return

    print(f"Recovered PIN: {result['pin']}")
    print(f"Guesses: {result['guesses']}")
    print(
        f"Actual attack time: "
        f"{result['time']:.4f} seconds"
    )
    print(
        f"Actual guessing rate: "
        f"{result['guesses_per_second']:.2f} guesses/sec"
    )


def main():

    pin = "1234"

    secret = (
        "This is our protected private key."
    )

    # Import here to avoid unnecessary
    # duplication of vault logic.
    from vault import create_vault

    # Create test vaults
    pbkdf2_vault = create_vault(
        pin,
        secret,
        kdf="pbkdf2"
    )

    argon2id_vault = create_vault(
        pin,
        secret,
        kdf="argon2id"
    )

    print("=== CONTROLLED 4-DIGIT PIN VALIDATION ===")
    print("Target PIN:", pin)
    print()

    # PBKDF2 attack
    pbkdf2_result = crack_pin(
        pbkdf2_vault["ciphertext"],
        pbkdf2_vault["nonce"],
        pbkdf2_vault["salt"],
        pin_length=4,
        kdf="pbkdf2"
    )

    print_results(
        "PBKDF2",
        pbkdf2_result
    )

    # Argon2id attack
    argon2id_result = crack_pin(
        argon2id_vault["ciphertext"],
        argon2id_vault["nonce"],
        argon2id_vault["salt"],
        pin_length=4,
        kdf="argon2id"
    )

    print_results(
        "ARGON2ID",
        argon2id_result
    )


if __name__ == "__main__":
    main()
    