
import hashlib
import os

from cryptography.exceptions import InvalidTag
from vault import (
    derive_key_pbkdf2,
    derive_key_argon2id,
    create_vault,
    decrypt_secret,
)
from cracker import crack_pin


passed = 0
total = 8


def check(name, condition):
    global passed
    if condition:
        passed += 1
        print(f"[PASS] {name}")
    else:
        print(f"[FAIL] {name}")


# 1. RFC 6070 PBKDF2-HMAC-SHA1 test vector
expected = bytes.fromhex(
    "0c60c80f961f0e71f3a9b524af6012062fe037a6"
)
actual = hashlib.pbkdf2_hmac(
    "sha1", b"password", b"salt", 1, dklen=20
)
check("RFC 6070 PBKDF2-HMAC-SHA1 vector", actual == expected)

# Fixed PIN and salt for reproducible key tests
pin = "42"
salt = b"validation-salt1"
secret = "Validation test secret"

# 2. PBKDF2 is deterministic
key_pbkdf2 = derive_key_pbkdf2(pin, salt)
check(
    "PBKDF2: same PIN and salt produce same key",
    key_pbkdf2 == derive_key_pbkdf2(pin, salt),
)

# 3. Argon2id is deterministic
key_argon = derive_key_argon2id(pin, salt)
check(
    "Argon2id: same PIN and salt produce same key",
    key_argon == derive_key_argon2id(pin, salt),
)

# 4. Changing the PIN changes the derived key
check(
    "Different PIN produces a different key",
    key_pbkdf2 != derive_key_pbkdf2("43", salt)
    and key_argon != derive_key_argon2id("43", salt),
)

# Create test vaults
vault_pbkdf2 = create_vault(pin, secret, "pbkdf2")
vault_argon = create_vault(pin, secret, "argon2id")

# 5. PBKDF2 vault decrypts with the correct PIN
recovered_pbkdf2 = decrypt_secret(
    vault_pbkdf2["ciphertext"],
    derive_key_pbkdf2(pin, vault_pbkdf2["salt"]),
    vault_pbkdf2["nonce"],
)
check("PBKDF2 vault decrypts with correct PIN", recovered_pbkdf2 == secret)

# 6. Argon2id vault decrypts with the correct PIN
recovered_argon = decrypt_secret(
    vault_argon["ciphertext"],
    derive_key_argon2id(pin, vault_argon["salt"]),
    vault_argon["nonce"],
)
check("Argon2id vault decrypts with correct PIN", recovered_argon == secret)

# 7. Wrong PIN is rejected by both vault types
wrong_pin_rejected = True
for vault, derive in [
    (vault_pbkdf2, derive_key_pbkdf2),
    (vault_argon, derive_key_argon2id),
]:
    try:
        decrypt_secret(
            vault["ciphertext"],
            derive("wrong-pin", vault["salt"]),
            vault["nonce"],
        )
        wrong_pin_rejected = False
    except InvalidTag:
        pass

check("Wrong PIN is rejected by both vault types", wrong_pin_rejected)

# 8. Cracker recovers a known two-digit PIN
target_pin = "07"
test_vault = create_vault(target_pin, secret, "pbkdf2")
crack_result = crack_pin(
    test_vault["ciphertext"],
    test_vault["nonce"],
    test_vault["salt"],
    pin_length=2,
    kdf="pbkdf2",
)
check(
    "Cracker finds the known two-digit PIN",
    crack_result is not None and crack_result["pin"] == target_pin,
)

print(f"\nValidation result: {passed}/{total} checks passed")
