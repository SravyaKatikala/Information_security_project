import os
import hashlib
from cryptography.hazmat.primitives.ciphers.aead import AESGCM
from argon2.low_level import hash_secret_raw, Type


def derive_key_pbkdf2(pin, salt):
    return hashlib.pbkdf2_hmac(
        "sha512",
        pin.encode(),
        salt,
        10_000,
        dklen=32
    )

def derive_key_argon2id(pin, salt, memory_kib=64 * 1024):
    return hash_secret_raw(
        secret=pin.encode(),
        salt=salt,
        time_cost=3,
        memory_cost=memory_kib,
        parallelism=4,
        hash_len=32,
        type=Type.ID
    )


def encrypt_secret(secret, key):
    aes = AESGCM(key)
    nonce = os.urandom(12)

    ciphertext = aes.encrypt(
        nonce,
        secret.encode(),
        None
    )

    return nonce, ciphertext

def decrypt_secret(ciphertext, key, nonce):
    aes = AESGCM(key)

    plaintext = aes.decrypt(
        nonce,
        ciphertext,
        None
    )

    return plaintext.decode()

def create_vault(pin, secret, kdf="pbkdf2"):
    salt = os.urandom(16)

    if kdf == "pbkdf2":
        key = derive_key_pbkdf2(pin, salt)

    elif kdf == "argon2id":
        key = derive_key_argon2id(pin, salt)

    else:
        raise ValueError("Unsupported KDF")

    nonce, ciphertext = encrypt_secret(secret, key)

    return {
        "salt": salt,
        "nonce": nonce,
        "ciphertext": ciphertext,
        "kdf": kdf
    }

if __name__ == "__main__":
    pin = "1234"
    secret = "This is our protected private key."

    # PBKDF2 vault
    pbkdf2_vault = create_vault(
        pin,
        secret,
        "pbkdf2"
    )

    pbkdf2_key = derive_key_pbkdf2(
        pin,
        pbkdf2_vault["salt"]
    )

    pbkdf2_recovered = decrypt_secret(
        pbkdf2_vault["ciphertext"],
        pbkdf2_key,
        pbkdf2_vault["nonce"]
    )

    print("=== PBKDF2 VAULT ===")
    print("KDF:", pbkdf2_vault["kdf"])
    print("Recovered:", pbkdf2_recovered)


    # Argon2id vault
    argon2_vault = create_vault(
        pin,
        secret,
        "argon2id"
    )

    argon2_key = derive_key_argon2id(
        pin,
        argon2_vault["salt"]
    )

    argon2_recovered = decrypt_secret(
        argon2_vault["ciphertext"],
        argon2_key,
        argon2_vault["nonce"]
    )

    print("\n=== ARGON2ID VAULT ===")
    print("KDF:", argon2_vault["kdf"])
    print("Recovered:", argon2_recovered)